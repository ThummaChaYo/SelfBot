#-*-coding:utf8;-*-
#qpy:2
#qpy:console

print "This is console module"
{}